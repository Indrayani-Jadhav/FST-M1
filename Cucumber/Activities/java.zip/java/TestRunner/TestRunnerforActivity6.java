package TestRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "Features",
        glue = {"stepDefinitions"},
        tags = "@activity1",
        plugin = {"pretty"},
        plugin = {"html: test-reports"},                                        //html report
        plugin = {"json: test-reports/json-report.json"},                       //json report same we can do for other
        monochrome = true
)
public class TestRunnerforActivity6
{
}
