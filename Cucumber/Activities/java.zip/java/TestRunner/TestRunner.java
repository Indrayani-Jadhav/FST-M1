package TestRunner;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions
        (
        features="src/test/java/Features",
        glue={"TestDefination"},
                tags="@activity4",
       // tags="@FirstFeatureScenario",     //optional if we want to run specific feature then we can use
                publish = true             //if report we want to be generate
        )
public final class TestRunner
{

}
