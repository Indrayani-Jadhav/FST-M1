package TestDefination;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class FirstTest extends BaseClass
{
    @Given("^User is on TS homepage")

    public void openTSHomepage()
    {
        // Written in BAsCLAss FirefoxDriver driver = new FirefoxDriver();
        driver.get("https://www.training-support.net");

    }
    @When("^user clicks on About Us Link$")
    public void clickAboutusLink()
    {
        driver.findElement(By.linkText("About Us")).click();
    }

    @Then("^They are redirected to About US page Link$")
    public void redirectToAboutUS()
    {
        String pagetitle=driver.getTitle();
        //Assertions
        assertEquals(pagetitle,"About Training Support");

    }


}
