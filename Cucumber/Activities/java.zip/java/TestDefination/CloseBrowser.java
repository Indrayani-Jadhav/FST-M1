package TestDefination;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static TestDefination.BaseClass.driver;

public class CloseBrowser extends BaseClass
{
    @Then("^Close the browser$")
            public void closeBrowser()
    {
       // driver.close();
        driver.quit();
    }

}
